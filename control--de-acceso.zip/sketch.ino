#include <Keypad.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

const byte FILAS = 4;
const byte COLUMNAS = 4;
char teclas[FILAS][COLUMNAS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

byte pinesFilas[FILAS] = {9, 8, 7, 6}; 
byte pinesColumnas[COLUMNAS] = {13, A0, A1, A2};

Keypad teclado = Keypad(makeKeymap(teclas), pinesFilas, pinesColumnas, FILAS, COLUMNAS);

LiquidCrystal_I2C lcd(0x27, 16, 2);

const int trigPin = 10;
const int echoPin = 11;
const int ledPin = 12;
const int buzzerPin = 3; // buzzer en pin 3

String codigoCorrecto = "1234"; // clave correcta
String entrada = "";
int intentos = 0;
bool alarmaActiva = false;

unsigned long ultimoParpadeo = 0;
bool estadoLED = false;
bool personaDetectada = false;

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  digitalWrite(ledPin, LOW);
  digitalWrite(buzzerPin, LOW);

  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Sistema Listo");
  Serial.begin(9600);
}

void loop() {
  long distancia = medirDistancia();

  if (distancia < 50) {
    if (!personaDetectada) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Ingrese clave:");
      personaDetectada = true;
    }
    parpadearLED();
    leerTeclado();
  } else {
    if (personaDetectada) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Esperando...");
      personaDetectada = false;
      entrada = "";
    }
  }
}

void leerTeclado() {
  char tecla = teclado.getKey();

  if (tecla) {
    if (tecla == '#') {
      verificarClave();
    } else if (tecla == '*') {
      entrada = "";
      lcd.setCursor(0, 1);
      lcd.print("Borrado          ");
    } else {
      entrada += tecla;
      lcd.setCursor(0, 1);
      lcd.print("Clave: " + entrada + "    ");
    }
  }
}

void verificarClave() {
  if (entrada == codigoCorrecto) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Acceso Permitido");
    delay(2000); // mantiene el mensaje visible durante este tiempo
    intentos = 0;
    if (alarmaActiva) {
      desactivarAlarma();
    }
  } else {
    intentos++;
    lcd.setCursor(0, 1);
    lcd.print("Clave Incorrecta");
    delay(2000); // mantiene el mensaje visible durante este tiempo

    if (intentos >= 3) { 
      activarAlarma();
    }
  }
  entrada = "";
}

void activarAlarma() {
  alarmaActiva = true;
  tone(buzzerPin, 1000); 
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("¡ALARMA ACTIVA!");
}

void desactivarAlarma() {
  alarmaActiva = false;
  noTone(buzzerPin);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Alarma desactiva");
  delay(2000);
}

void parpadearLED() {
  unsigned long ahora = millis();
  if (ahora - ultimoParpadeo >= 200) {
    estadoLED = !estadoLED;
    digitalWrite(ledPin, estadoLED);
    ultimoParpadeo = ahora;
  }
}

long medirDistancia() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duracion = pulseIn(echoPin, HIGH, 20000); 
  if (duracion == 0) return 999; 
  long distancia = duracion * 0.034 / 2;
  return distancia;
}
